from flask import Flask, request, redirect, jsonify
import string
import random
from datetime import datetime

app = Flask(__name__)

# Datastore to store shortcodes and their details
shortcodes = {}

def generate_shortcode():
    characters = string.ascii_letters + string.digits + "_"
    return ''.join(random.choice(characters) for _ in range(6))

@app.route('/shorten', methods=['POST'])
def shorten_url():
    data = request.json
    url = data.get('url')
    shortcode = data.get('shortcode')

    if not url:
        return jsonify({"error": "Url not present"}), 400

    if shortcode:
        if shortcode in shortcodes:
            return jsonify({"error": "Shortcode already in use"}), 409
        if len(shortcode) != 6 or not shortcode.isalnum():
            return jsonify({"error": "The provided shortcode is invalid"}), 412
    else:
        shortcode = generate_shortcode()
        while shortcode in shortcodes:
            shortcode = generate_shortcode()

    shortcodes[shortcode] = {
        "url": url,
        "created": datetime.now().isoformat(),
        "lastRedirect": None,
        "redirectCount": 0
    }

    return jsonify({"shortcode": shortcode}), 201

@app.route('/<shortcode>', methods=['GET'])
def redirect_to_url(shortcode):
    if shortcode not in shortcodes:
        return jsonify({"error": "Shortcode not found"}), 404
    
    shortcodes[shortcode]["lastRedirect"] = datetime.now().isoformat()
    shortcodes[shortcode]["redirectCount"] += 1

    return redirect(shortcodes[shortcode]["url"], code=302)

@app.route('/<shortcode>/stats', methods=['GET'])
def get_stats(shortcode):
    if shortcode not in shortcodes:
        return jsonify({"error": "Shortcode not found"}), 404
    
    return jsonify({
        "created": shortcodes[shortcode]["created"],
        "lastRedirect": shortcodes[shortcode]["lastRedirect"],
        "redirectCount": shortcodes[shortcode]["redirectCount"]
    }), 200

if __name__ == '__main__':
    app.run(debug=True)
