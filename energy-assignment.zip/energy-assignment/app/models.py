from datetime import datetime

class ShortenedURL:
    def __init__(self, url, shortcode=None):
        self.url = url
        self.shortcode = shortcode
        self.created = datetime.utcnow()
        self.last_redirect = None
        self.redirect_count = 0

    def record_redirect(self):
        self.last_redirect = datetime.utcnow()
        self.redirect_count += 1
