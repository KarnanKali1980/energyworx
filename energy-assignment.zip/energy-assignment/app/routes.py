from flask import Flask, request, jsonify, redirect
from .models import ShortenedURL
from .utils import generate_shortcode
import json

app = Flask(__name__)
urls = {}

@app.route('/shorten', methods=['POST'])
def shorten_url():
    data = request.get_json()
    if 'url' not in data:
        return 'Url not present', 400
    url = data['url']
    shortcode = data.get('shortcode', None)
    
    if shortcode:
        if shortcode in urls:
            return 'Shortcode already in use', 409
        if not shortcode.isalnum() or len(shortcode) != 6:
            return 'The provided shortcode is invalid', 412
    else:
        while True:
            shortcode = generate_shortcode()
            if shortcode not in urls:
                break
    
    urls[shortcode] = ShortenedURL(url, shortcode)
    return jsonify({'shortcode': shortcode}), 201

@app.route('/<shortcode>', methods=['GET'])
def redirect_to_url(shortcode):
    if shortcode not in urls:
        return 'Shortcode not found', 404
    urls[shortcode].record_redirect()
    return redirect(urls[shortcode].url, code=302)

@app.route('/<shortcode>/stats', methods=['GET'])
def get_stats(shortcode):
    if shortcode not in urls:
        return 'Shortcode not found', 404
    data = {
        'created': urls[shortcode].created.isoformat(),
        'lastRedirect': urls[shortcode].last_redirect.isoformat() if urls[shortcode].last_redirect else None,
        'redirectCount': urls[shortcode].redirect_count
    }
    return jsonify(data), 200
