import unittest
from app import app

class TestRoutes(unittest.TestCase):
    def setUp(self):
        app.testing = True
        self.app = app.test_client()

    def test_shorten_url(self):
        data = {'url': 'https://www.energyworx.com/'}
        response = self.app.post('/shorten', json=data)
        self.assertEqual(response.status_code, 201)
        self.assertIn(b'shortcode', response.data)

    def test_redirect_to_url(self):
        response = self.app.get('/abc123')
        self.assertEqual(response.status_code, 404)

    def test_get_stats(self):
        response = self.app.get('/abc123/stats')
        self.assertEqual(response.status_code, 404)

if __name__ == '__main__':
    unittest.main()
