import unittest
import json
from run import app

class TestURLShortener(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_shorten_url(self):
        data = json.dumps({"url": "https://www.energyworx.com/"})
        response = self.app.post('/shorten', headers={"Content-Type": "application/json"}, data=data)
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 201)
        self.assertTrue("shortcode" in data)
        

    def test_redirect_to_url(self):
        response = self.app.get('/pqeHFu')  # Replace <shortcode> with actual shortcode
        self.assertEqual(response.status_code, 302)

    def test_get_stats(self):
        response = self.app.get('/pqeHFu/stats')  # Replace <shortcode> with actual shortcode
        self.assertEqual(response.status_code, 200)

if __name__ == '__main__':
    unittest.main()
